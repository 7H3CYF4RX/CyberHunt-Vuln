#!/bin/bash

# CyberHunt - Security Training Lab
# Start Script

# Colors
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'
BOLD='\033[1m'

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Banner
echo ""
echo -e "${CYAN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║                                                           ║${NC}"
echo -e "${CYAN}║   ${BOLD}🎯 CyberHunt - Security Training Lab${NC}${CYAN}                    ║${NC}"
echo -e "${CYAN}║   ${NC}OWASP Top 10 Vulnerable Web Application${CYAN}                ║${NC}"
echo -e "${CYAN}║                                                           ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check PHP
if ! command -v php &> /dev/null; then
    echo -e "${RED}[ERROR]${NC} PHP is not installed. Please install PHP 8.x"
    echo ""
    echo "  Install on Debian/Ubuntu/Kali:"
    echo "    sudo apt install php php-sqlite3"
    echo ""
    echo "  Install on Arch:"
    echo "    sudo pacman -S php php-sqlite"
    echo ""
    exit 1
fi

PHP_VERSION=$(php -v | head -n 1 | cut -d ' ' -f 2)
echo -e "${GREEN}[✓]${NC} PHP version: $PHP_VERSION"

# Check for SQLite PDO driver
if ! php -m 2>/dev/null | grep -qi "pdo_sqlite"; then
    echo -e "${RED}[ERROR]${NC} PHP SQLite extension is not installed!"
    echo ""
    echo -e "  ${YELLOW}Install on Debian/Ubuntu/Kali:${NC}"
    echo "    sudo apt install php-sqlite3"
    echo ""
    echo -e "  ${YELLOW}Install on Arch:${NC}"
    echo "    sudo pacman -S php-sqlite"
    echo ""
    echo -e "  ${YELLOW}Install on Fedora:${NC}"
    echo "    sudo dnf install php-pdo"
    echo ""
    echo "  After installing, restart the script: ./start.sh"
    echo ""
    exit 1
fi

echo -e "${GREEN}[✓]${NC} PHP SQLite extension found"

# Create necessary directories
mkdir -p database uploads/profiles exports

# Reset and Initialize Database on every restart
echo -e "${YELLOW}[!]${NC} Initializing fresh database..."
rm -f database/cyberhunt.db
php database/init.php 2>&1
if [ $? -eq 0 ]; then
    echo -e "${GREEN}[✓]${NC} Database initialized (100 users, 50 products, 200 orders)"
else
    echo -e "${RED}[ERROR]${NC} Database initialization failed"
    echo "  Check if php-sqlite3 is installed correctly"
    exit 1
fi

# Kill existing PHP server on port 8080
if command -v lsof &> /dev/null; then
    if lsof -Pi :8080 -sTCP:LISTEN -t >/dev/null 2>&1; then
        echo -e "${YELLOW}[!]${NC} Stopping existing server on port 8080..."
        kill $(lsof -Pi :8080 -sTCP:LISTEN -t) 2>/dev/null
        sleep 1
    fi
fi

# Start server
PORT=${1:-8080}
echo ""
echo -e "${GREEN}[✓]${NC} Starting CyberHunt on port $PORT..."
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "   ${BOLD}🌐 Access the application at:${NC}"
echo -e "   ${GREEN}http://localhost:$PORT/${NC}"
echo ""
echo -e "   ${BOLD}� Test Credentials:${NC}"
echo -e "   ${YELLOW}admin / admin123${NC}  (Admin)"
echo -e "   ${YELLOW}testuser / password123${NC}  (User)"
echo ""
echo -e "   ${BOLD}📖 Documentation:${NC}"
echo -e "   ${YELLOW}VULNERABILITIES.md${NC}"
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}[!]${NC} Press Ctrl+C to stop the server"
echo ""

# Start PHP built-in server with router for proper 404 handling
php -S localhost:$PORT router.php
