# 🎯 CyberHunt - Security Training Lab

> A deliberately vulnerable e-commerce web application designed for security training and penetration testing practice.

![PHP](https://img.shields.io/badge/PHP-8.x-777BB4?logo=php)
![Bootstrap](https://img.shields.io/badge/Bootstrap-5.3-7952B3?logo=bootstrap)
![SQLite](https://img.shields.io/badge/SQLite-3-003B57?logo=sqlite)
![License](https://img.shields.io/badge/License-Educational-green)

---

## ⚠️ WARNING

**This application is INTENTIONALLY VULNERABLE!**

- Do NOT deploy in production
- Do NOT use on public networks
- For educational purposes ONLY
- Use in isolated/sandboxed environments

---

## 🚀 Quick Start

```bash
# Navigate to directory
cd CyberHunt

# Start the application
./start.sh

# Or manually:
php -S localhost:8080 router.php
```

**Access:** http://localhost:8080

---

## 🔐 Test Credentials

| Username | Password | Role |
|----------|----------|------|
| `admin` | `admin123` | Admin |
| `testuser` | `password123` | User |

**SQL Injection Login Bypass:**
```
Username: admin' --
Password: anything
```

---

## 🎟️ Coupon Codes

| Code | Discount | Notes |
|------|----------|-------|
| `WELCOME10` | 10% off | Popup after login |
| `GRAND20` | 20% off | Shown in banner |
| `FLAT50` | $50 off | Hidden |

**Vulnerability:** Alternate between coupons to stack unlimited discounts!

---

## 🔥 Vulnerabilities Included

| # | Vulnerability | Location |
|---|---------------|----------|
| 1 | **SQL Injection** | Login, Search, Products |
| 2 | **XSS (Reflected)** | Search (filter bypass) |
| 3 | **XSS (Stored)** | Reviews, Messages, Profile |
| 4 | **Path Traversal** | API, Export |
| 5 | **SSRF** | API fetch endpoint |
| 6 | **IDOR** | User data, Orders |
| 7 | **Command Injection** | Contact form |
| 8 | **Broken Auth** | Weak hashing, Secret Q&A |
| 9 | **Sensitive Data Exposure** | API, Comments |
| 10 | **Business Logic** | Coupon stacking |

---

## 🔧 Quick Test Commands

```bash
# Path Traversal
curl "http://localhost:8080/api.php?action=file&name=../../../etc/passwd"

# SSRF
curl "http://localhost:8080/api.php?action=fetch&url=file:///etc/passwd"

# User Enumeration
curl "http://localhost:8080/api.php?action=users&limit=10"

# XSS (filter bypass - open in browser)
http://localhost:8080/search.php?q=<img src=x onerror=alert(1)>
```

---

## 📁 Directory Structure

```
CyberHunt/
├── admin/              # Admin panel
├── api.php             # Vulnerable API endpoint
├── assets/             # CSS, JS, images
├── config/             # Database configuration
├── database/           # SQLite database
├── exports/            # User data exports
├── fake_root/          # Simulated filesystem
│   ├── etc/            # passwd, shadow, hosts
│   ├── home/           # admin notes, SSH keys, .env
│   └── var/log/        # auth.log, app.log
├── includes/           # Header & footer
├── router.php          # 404 handling
└── start.sh            # Startup script
```

---

## 🔍 Discovery Points

- **View Page Source** - Hidden API endpoints in HTML comments
- **robots.txt** - Exposed admin paths
- **Error Messages** - SQL errors reveal query structure

---

## 📚 Documentation

- **[VULNERABILITIES.md](VULNERABILITIES.md)** - Detailed vulnerability guide
- **[../SOLUTION.md](../SOLUTION.md)** - Full solutions (spoilers!)

---

## 🛠️ Technology Stack

- **Backend:** PHP 8.x
- **Frontend:** Bootstrap 5, Custom CSS
- **Database:** SQLite 3
- **Icons:** Bootstrap Icons
- **Fonts:** Inter (Google Fonts)

---

## 🎓 Learning Objectives

- SQL Injection exploitation
- XSS filter bypass techniques
- Path traversal attacks
- SSRF and IDOR vulnerabilities
- Business logic flaws
- Information disclosure

---

## 👥 Contributors

<table>
  <tr>
    <td align="center">
      <a href="https://github.com/MRG6OOT">
        <b>@MRG6OOT</b>
      </a>
    </td>
    <td align="center">
      <a href="https://github.com/Sensei-Glitch99">
        <b>@Sensei-Glitch99</b>
      </a>
    </td>
  </tr>
</table>

---

## ⚖️ License

**For educational purposes only.**

Do NOT use for malicious purposes.

---

Happy Hacking! 🎯
